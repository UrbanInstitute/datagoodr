source("mutate.R")

Pa <- readLines("date1.txt")   # M/D/YY
Pb <- readLines("date3.txt")   # YYYY-MM-DD

validator_date_a <- function(x) {
  d <- as.Date(x, format = "%m/%d/%y", optional = TRUE)
  !is.na(d) & grepl("^\\d{1,2}/\\d{1,2}/\\d{2}$", x)
}
validator_date_b <- function(x) {
  d <- as.Date(x, format = "%Y-%m-%d", optional = TRUE)
  !is.na(d) & grepl("^\\d{4}-\\d{2}-\\d{2}$", x)
}

res_a <- build_results_table(validator_date_a, Pa)
res_b <- build_results_table(validator_date_b, Pb)

generate_report(res_a, "date M/D/YY")
generate_report(res_b, "date YYYY-MM-DD")

summary_tbl <- rbind(
  summary_row("date M/D/YY", Pa, res_a),
  summary_row("date YYYY-MM-DD", Pb, res_b)
)
cat("=== SUMMARY TABLE ===\n")
print(summary_tbl, row.names = FALSE, digits = 3)
saveRDS(summary_tbl, "summary_date.rds")
