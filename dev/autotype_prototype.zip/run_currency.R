source("mutate.R")
library(readr)

P1 <- read_lines("currency.txt")
P2 <- read_lines("currency2.txt")
P3 <- read_lines("currency3.txt")

iso4217_codes <- c(
  "AED","AFN","ALL","AMD","ANG","AOA","ARS","AUD","AWG","AZN","BAM","BBD","BDT",
  "BGN","BHD","BIF","BMD","BND","BOB","BRL","BSD","BTN","BWP","BYN","BZD","CAD",
  "CDF","CHF","CLP","CNY","COP","CRC","CUP","CVE","CZK","DJF","DKK","DOP","DZD",
  "EGP","ERN","ETB","EUR","FJD","FKP","GBP","GEL","GHS","GIP","GMD","GNF","GTQ",
  "GYD","HKD","HNL","HRK","HTG","HUF","IDR","ILS","INR","IQD","IRR","ISK","JMD",
  "JOD","JPY","KES","KGS","KHR","KMF","KPW","KRW","KWD","KYD","KZT","LAK","LBP",
  "LKR","LRD","LSL","LYD","MAD","MDL","MGA","MKD","MMK","MNT","MOP","MRU","MUR",
  "MVR","MWK","MXN","MYR","MZN","NAD","NGN","NIO","NOK","NPR","NZD","OMR","PAB",
  "PEN","PGK","PHP","PKR","PLN","PYG","QAR","RON","RSD","RUB","RWF","SAR","SBD",
  "SCR","SDG","SEK","SGD","SHP","SLE","SOS","SRD","SSP","STN","SYP","SZL","THB",
  "TJS","TMT","TND","TOP","TRY","TTD","TWD","TZS","UAH","UGX","USD","UYU","UZS",
  "VES","VND","VUV","WST","XAF","XCD","XOF","XPF","YER","ZAR","ZMW","ZWL"
)

validator_code <- function(x) toupper(x) %in% iso4217_codes
validator_symbol_amount <- function(x) grepl("^[$\u20ac\u00a5\u00a3]\\d+(\\.\\d{1,2})?$", x)
validator_code_symbol_amount <- function(x) {
  m <- regmatches(x, regexec("^([A-Z]{3})[$\u20ac\u00a5\u00a3]\\d+(\\.\\d{1,2})?$", x))
  ok_syntax <- lengths(m) > 0
  code <- vapply(m, function(mm) if (length(mm) >= 2) mm[2] else NA_character_, character(1))
  ok_syntax & (code %in% iso4217_codes)
}

res1 <- build_results_table(validator_code, P1)
res2 <- build_results_table(validator_symbol_amount, P2)
res3 <- build_results_table(validator_code_symbol_amount, P3)

generate_report(res1, "currency code (ISO 4217 lookup)")
generate_report(res2, "symbol + amount (regex, max 2 decimals)")
generate_report(res3, "code + symbol + amount (regex + lookup)")

summary_tbl <- rbind(
  summary_row("currency code", P1, res1),
  summary_row("symbol+amount", P2, res2),
  summary_row("code+symbol+amount", P3, res3)
)
cat("=== SUMMARY TABLE ===\n")
print(summary_tbl, row.names = FALSE, digits = 3)
saveRDS(summary_tbl, "summary_currency.rds")
