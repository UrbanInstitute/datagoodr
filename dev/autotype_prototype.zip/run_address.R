source("mutate.R")

P <- readLines("us_address.txt")

validator_address <- function(x) {
  m <- regmatches(x, regexec("^(.+),\\s*([A-Za-z .'-]+),\\s*(\\d{5})$", x))
  ok_shape <- lengths(m) == 4
  zip <- vapply(m, function(mm) if (length(mm) == 4) mm[4] else NA_character_, character(1))
  zip_ok <- !is.na(zip) & as.integer(zip) >= 501 & as.integer(zip) <= 99950
  street <- vapply(m, function(mm) if (length(mm) == 4) mm[2] else NA_character_, character(1))
  street_kw <- "\\d|\\b(St|Ave|Rd|Dr|Blvd|Ct|Ln|Way|Pl|Ter|Cir|Pkwy|Hwy|Ste|Fwy|Frst)\\b"
  street_ok <- !is.na(street) & grepl(street_kw, street, ignore.case = TRUE)
  ok_shape & zip_ok & street_ok
}

res <- build_results_table(validator_address, P)
generate_report(res, "US address (street, city, zip)")

summary_tbl <- summary_row("address", P, res)
cat("=== SUMMARY TABLE ===\n")
print(summary_tbl, row.names = FALSE, digits = 3)
saveRDS(summary_tbl, "summary_address.rds")
