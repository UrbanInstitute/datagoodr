## mutate.R
## Reimplementation of AutoType's (Yan & He, SIGMOD'18) hierarchical
## negative-example generation: Definition 5 (inferred alphabet) and
## the S1 (preserve-structure) / S2 (preserve-alphabet) / S3 (random)
## mutation strategies from Section 6.

## ---- alphabet inference (Definition 5) ------------------------------------

#' Infer the alphabet of a set of positive examples P.
#' Returns the full set of characters seen, split into the
#' "non-punctuation" (alphanumeric) subset and the "punctuation"
#' (everything else -- includes currency symbols, delimiters, etc.)
#' subset, exactly as AutoType's Sigma(P) / Sigma_{\bar P}(P) split.
infer_alphabet <- function(P) {
  chars <- unique(unlist(strsplit(paste(P, collapse = ""), "")))
  is_alnum <- grepl("^[A-Za-z0-9]$", chars)
  list(
    full     = chars,
    nonpunct = chars[is_alnum],   # letters + digits actually observed
    punct    = chars[!is_alnum]   # delimiters, symbols, spaces, etc.
  )
}

## ---- the three mutation strategies (Section 6) ----------------------------

.mutate_string <- function(s, p, replace_pool, eligible_fn) {
  chars <- strsplit(s, "")[[1]]
  eligible <- eligible_fn(chars)
  do_mutate <- eligible & (runif(length(chars)) < p)
  if (any(do_mutate) && length(replace_pool) > 0) {
    chars[do_mutate] <- sample(replace_pool, sum(do_mutate), replace = TRUE)
  }
  paste(chars, collapse = "")
}

#' S1. Mutate-preserve-structure: replace in-alphabet NON-punctuation
#' characters only, leaving punctuation/delimiters untouched. Least
#' aggressive -- for checksum/structured types this alone often yields
#' true negatives; for loosely-structured types it mostly regenerates
#' new positives.
mutate_S1 <- function(s, alphabet, p = 0.5) {
  is_alnum <- function(chars) grepl("^[A-Za-z0-9]$", chars)
  .mutate_string(s, p, alphabet$nonpunct, is_alnum)
}

#' S2. Mutate-preserve-alphabet: replace ANY in-alphabet character
#' (punctuation included) with another character drawn from the full
#' observed alphabet. This can corrupt delimiters/structure.
mutate_S2 <- function(s, alphabet, p = 0.5) {
  always_eligible <- function(chars) rep(TRUE, length(chars))
  .mutate_string(s, p, alphabet$full, always_eligible)
}

#' S3. Mutate-random: replace in-alphabet characters with any character
#' drawn from a generic printable-ASCII pool, not limited to what was
#' observed in P. Most aggressive; needed for types whose alphabet is a
#' closed small set (e.g. gene sequences, roman numerals) where S1/S2
#' can't otherwise produce a genuine negative.
.generic_pool <- c(letters, LETTERS, as.character(0:9),
                    strsplit("!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~ ", "")[[1]])
mutate_S3 <- function(s, alphabet, p = 0.5) {
  always_eligible <- function(chars) rep(TRUE, length(chars))
  .mutate_string(s, p, .generic_pool, always_eligible)
}

## ---- SP. Structure-scramble (complement of S1) ----------------------------
## S1 keeps punctuation positions fixed and substitutes alphanumeric
## *identity*. SP is the mirror image: alphanumeric identity and relative
## order are preserved exactly (same digits/letters, same sequence), and
## only the *position* of punctuation/structural characters is permuted.
## This targets a failure mode S1-S3 can't reach at all: a validator that
## checks "right characters present" but never checks "in the right
## place" (decimal-point position, thousands-grouping, symbol ordering
## in things like 5'10").
mutate_SP <- function(s, p = 1.0) {
  chars <- strsplit(s, "")[[1]]
  n <- length(chars)
  is_alnum <- grepl("^[A-Za-z0-9]$", chars)
  punct_idx <- which(!is_alnum)
  if (length(punct_idx) == 0) return(s)   # nothing structural to scramble
  move <- runif(length(punct_idx)) < p
  if (!any(move)) return(s)
  moving_chars <- sample(chars[punct_idx[move]])   # also shuffle their order
  fixed_chars  <- chars[-punct_idx[move]]           # everything else, in order
  new_pos <- sort(sample(seq_len(n), length(moving_chars)))
  out <- character(n)
  out[new_pos] <- moving_chars
  out[-new_pos] <- fixed_chars
  paste(out, collapse = "")
}

## ---- wrapper: generate a batch of negatives for a given tier -------------

#' Generate `n_per_positive` mutated (likely-negative) strings for each
#' example in P, using mutation tier "S1", "S2", "S3", or "SP".
generate_negatives <- function(P, tier = c("S1", "S2", "S3", "SP"),
                                n_per_positive = 10, p = 0.5, seed = NULL) {
  tier <- match.arg(tier)
  if (!is.null(seed)) set.seed(seed)
  alphabet <- infer_alphabet(P)
  out <- character(0)
  for (s in P) {
    for (i in seq_len(n_per_positive)) {
      mutated <- switch(tier,
        S1 = mutate_S1(s, alphabet, p),
        S2 = mutate_S2(s, alphabet, p),
        S3 = mutate_S3(s, alphabet, p),
        SP = mutate_SP(s, p)
      )
      out <- c(out, mutated)
    }
  }
  unique(out)
}

## ---- structured results table ---------------------------------------------

#' Run `validator` against the real positive examples P and against
#' negatives generated at each mutation tier, and return one tidy table:
#'   case      - the string tested
#'   type      - "valid", "S1", "S2", "S3", or "SP"
#'   f_match   - the validator's raw output for that case (logical, or a
#'               numeric score/probability if the validator returns one)
#'   f_predict - the T/F prediction actually used for scoring: f_match
#'               itself when already logical, otherwise f_match > threshold
build_results_table <- function(validator, P, tiers = c("S1", "S2", "S3", "SP"),
                                 n_per_positive = 20, p = 0.5, seed = 514,
                                 threshold = 0.5) {
  as_predict <- function(x) if (is.logical(x)) x else (x > threshold)
  f_valid <- validator(P)
  rows <- list(data.frame(
    case = P, type = "valid",
    f_match = f_valid, f_predict = as_predict(f_valid),
    stringsAsFactors = FALSE
  ))
  for (tier in tiers) {
    N <- generate_negatives(P, tier, n_per_positive, p, seed = seed)
    N <- setdiff(N, P)   # drop mutations that happen to reproduce a real positive
    if (length(N) == 0) next
    f_neg <- validator(N)
    rows[[tier]] <- data.frame(
      case = N, type = tier,
      f_match = f_neg, f_predict = as_predict(f_neg),
      stringsAsFactors = FALSE
    )
  }
  do.call(rbind, rows)
}

#' Per-type n / pass-rate summary from a results table (same numbers
#' print_evaluation() reports, but as a data frame).
summarize_results <- function(results) {
  out <- aggregate(f_predict ~ type, data = results,
                    FUN = function(x) c(n = length(x), pass_rate = mean(x)))
  data.frame(type = out$type, n = out$f_predict[, "n"],
             pass_rate = out$f_predict[, "pass_rate"])
}

#' One row for a master markdown-style summary table across types,
#' with an Example column (1-3 real positive examples, ";; "-joined).
summary_row <- function(type_label, P, results, n_examples = 3) {
  s <- summarize_results(results)
  get_rate <- function(t) {
    v <- s$pass_rate[s$type == t]
    if (length(v) == 0) NA else v
  }
  data.frame(
    Type = type_label,
    Example = paste(head(P, n_examples), collapse = ";; "),
    Recall = get_rate("valid"),
    S1 = get_rate("S1"), S2 = get_rate("S2"),
    S3 = get_rate("S3"), SP = get_rate("SP")
  )
}

#' Error report: false negatives among "valid" cases (real positives the
#' validator rejected), and up to `n_examples` false positives per
#' mutation tier (negatives the validator wrongly accepted).
generate_report <- function(results, type_name, n_examples = 3) {
  cat("################  ERROR REPORT:", type_name, "################\n\n")
  fn <- results$case[results$type == "valid" & !results$f_predict]
  cat(sprintf("False negatives -- real positives REJECTED (%d):\n", length(fn)))
  if (length(fn) > 0) cat("  ", paste(head(fn, n_examples), collapse = " | "), "\n")
  cat("\n")
  for (tier in setdiff(unique(results$type), "valid")) {
    sub <- results[results$type == tier, ]
    fp <- sub$case[sub$f_predict]
    cat(sprintf("%s false positives -- negatives wrongly ACCEPTED (%d / %d, %.1f%%):\n",
                tier, length(fp), nrow(sub), 100 * length(fp) / max(1, nrow(sub))))
    if (length(fp) > 0) cat("  ", paste(head(fp, n_examples), collapse = " | "), "\n")
    cat("\n")
  }
}
